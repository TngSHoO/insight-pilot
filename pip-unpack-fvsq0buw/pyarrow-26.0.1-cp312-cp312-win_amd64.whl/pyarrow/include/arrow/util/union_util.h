// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

#include <cstdint>
#include "arrow/array/data.h"

namespace arrow {
namespace union_util {

/// \brief Compute the number of of logical nulls in a sparse union array
ARROW_EXPORT
int64_t LogicalSparseUnionNullCount(const ArraySpan& span);

/// \brief Compute the number of of logical nulls in a dense union array
ARROW_EXPORT
int64_t LogicalDenseUnionNullCount(const ArraySpan& span);

/// \brief Populate a bitmap based on the logical nulls in a sparse union array
///
/// `set_on_null` is true if we should set bits corresponding to nulls and false if
/// we should set bits corresponding to non-nulls
ARROW_EXPORT
void SetLogicalNullBitsSparse(const ArraySpan& span, uint8_t* out_bitmap,
                              int64_t out_offset, bool set_on_null);

/// \brief Populate a bitmap based on the logical nulls in a dense union array
///
/// `set_on_null` is true if we should set bits corresponding to nulls and false if
/// we should set bits corresponding to non-nulls
ARROW_EXPORT
void SetLogicalNullBitsDense(const ArraySpan& span, uint8_t* out_bitmap,
                             int64_t out_offset, bool set_on_null);

}  // namespace union_util
}  // namespace arrow
